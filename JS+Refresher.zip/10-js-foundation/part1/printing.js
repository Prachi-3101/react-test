console.log("Hello");
console.log("chai");
process.stdout.write("chai");
process.stdout.write("chai");

console.table({ city: "Jaipur" });
console.warn({ city: "Jaipur" });
