let score = 10 + 11;

let num1 = 10;

// num1 = num1 + 5
num1 /= 5;

console.log(num1);
