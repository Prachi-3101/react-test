function sayHello() {
  console.log("I would like to say Hello");
}

setTimeout(() => {
  sayHello();
}, 4000);

console.log("chaicode");

for (let index = 0; index < 10; index++) {
  console.log(index);
}
