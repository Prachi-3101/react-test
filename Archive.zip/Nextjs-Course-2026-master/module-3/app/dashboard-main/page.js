import React from 'react'

const DashboardMainpage = () => {
  return (
    <div>DashboardMainpage</div>
  )
}

export default DashboardMainpage