import React from 'react'

const Profile = () => {
  return (
    <div>Full Profile Page</div>
  )
}

export default Profile