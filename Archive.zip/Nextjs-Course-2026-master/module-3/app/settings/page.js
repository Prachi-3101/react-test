import React from 'react'

const SettingPage = () => {
  return (
    <div>Full Setting Page</div>
  )
}

export default SettingPage