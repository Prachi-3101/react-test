export default function AdminPage() {
  return <h1>Full Admin Page</h1>;
}
