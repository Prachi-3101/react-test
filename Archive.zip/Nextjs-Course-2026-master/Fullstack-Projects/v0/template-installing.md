for build your  template
```bash 
cd sandbox-templates/nextjs e2b template build --name v0-nextjs-build-new --cmd "/compile_page.sh"
```

after successfully adding template make sure to make it public --> find a team id

run a command --> 
```bash
    e2b template publish -t <team-id>
```

also add your api key as well