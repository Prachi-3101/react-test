
import React from 'react'

const AboutPage = () => {
  return (
    <div>
       About
    </div>
  )
}

export default AboutPage